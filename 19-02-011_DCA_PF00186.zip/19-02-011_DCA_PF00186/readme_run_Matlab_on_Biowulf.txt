step 1: sinteractive
step 2: module load matlab/2018b
step 3: mcc2 -m dca.m
step 4: ./submit_dca.sh  
