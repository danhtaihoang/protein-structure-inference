import os

os.system('python 1main.py PF00008')
