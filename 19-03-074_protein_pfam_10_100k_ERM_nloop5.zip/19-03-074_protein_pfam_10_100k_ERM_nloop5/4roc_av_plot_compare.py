# 2018.12.27: Receiver operating characteristic (ROC) curve
import sys
import numpy as np
#import matplotlib
#matplotlib.use('TkAgg')
import matplotlib.pyplot as plt
#=========================================================================================

ct_thres_list = [1.5,2.0,3.0,4.0]
n = len(ct_thres_list)
   
plt.figure(figsize=(3.0*n,3.2))

for i,ct_thres in enumerate(ct_thres_list):
    fptp = np.loadtxt('roc_av_40_100k_%s.dat'%(ct_thres)).astype(float)
    fp = fptp[:,0]
    tp = fptp[:,1]
    std = fptp[:,2]
    auc = tp.sum()/tp.shape[0]

    # DCA
    fptp2 = np.loadtxt('roc_av_40_100k_%s_DCA.dat'%(ct_thres)).astype(float)
    fp2 = fptp2[:,0]
    tp2 = fptp2[:,1]
    std2 = fptp2[:,2]
    auc2 = tp2.sum()/tp2.shape[0]

    # ERM
    fptp3 = np.loadtxt('roc_av_40_100k_%s_ERM.dat'%(ct_thres)).astype(float)
    fp3 = fptp3[:,0]
    tp3 = fptp3[:,1]
    std3 = fptp3[:,2]
    auc3 = tp3.sum()/tp3.shape[0]

    plt.subplot2grid((1,n),(0,i))
    plt.title('thres=%2.1f,auc=%5.4f'%(ct_thres,auc))
    #plt.errorbar(fp,tp,std)
    plt.plot(fp2,tp2,'k-',label='DCA')
    plt.plot(fp,tp,'r-',label='ER')
    plt.plot(fp3,tp3,'b-',label='ERM')

    #plt.fill_between(fp,tp-std,tp+std)
    #plt.fill_between(fp2,tp2-std2,tp2+std2)
    plt.plot([0,1],[0,1],'k--')
    plt.xlim([0,1])
    plt.ylim([0,1])
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.legend()

plt.tight_layout(h_pad=1, w_pad=1.5)
plt.savefig('roc_av_compare.pdf', format='pdf', dpi=100)
