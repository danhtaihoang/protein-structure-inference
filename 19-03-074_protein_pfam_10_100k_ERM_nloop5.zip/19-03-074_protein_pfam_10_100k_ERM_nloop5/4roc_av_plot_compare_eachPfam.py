# 2018.12.27: Receiver operating characteristic (ROC) curve
import sys
import numpy as np
#import matplotlib
#matplotlib.use('TkAgg')
import matplotlib.pyplot as plt
#=========================================================================================
s = np.loadtxt('pfam_40_200k.txt',dtype='str')
pfam_list = s[:,0]

#pfam = 'PF00004'

ct_thres_list = [1.5,2.0,3.0,4.0]
n = len(ct_thres_list)

for pfam in pfam_list:   
    plt.figure(figsize=(3.0*n,3.2))
    for i,ct_thres in enumerate(ct_thres_list):
        # ER
        fptp = np.loadtxt('%s/roc_%s.dat'%(pfam,ct_thres)).astype(float)
        fp = fptp[:,0]
        tp = fptp[:,1]
        auc = tp.sum()/tp.shape[0]

        # DCA
        fptp2 = np.loadtxt('../19-03-071_protein_pfam_10_100k_DCA/%s/roc_%s.dat'%(pfam,ct_thres)).astype(float)
        fp2 = fptp2[:,0]
        tp2 = fptp2[:,1]
        auc2 = tp2.sum()/tp2.shape[0]

        # plot
        plt.subplot2grid((1,n),(0,i))
        plt.title('thres=%2.1f,auc=%5.4f,%5.4f'%(ct_thres,auc2,auc))
        plt.plot(fp2,tp2,'b--',label='DCA')
        plt.plot(fp,tp,'k-',label='ER')

        plt.plot([0,1],[0,1],'r--')
        plt.xlim([0,1])
        plt.ylim([0,1])
        plt.xlabel('False Positive Rate')
        plt.ylabel('True Positive Rate')
        plt.legend()

    plt.tight_layout(h_pad=1, w_pad=1.5)
    plt.savefig('%s/roc_compare.pdf'%(pfam), format='pdf', dpi=100)
    plt.close()

