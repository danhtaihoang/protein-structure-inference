import sys
import numpy as np

seed = 1
np.random.seed(seed)

s = np.loadtxt('pfam_40_200k.txt',dtype='str')
pfam_list = s[:,0]

#pfam_id = 'PF00004'
#pfam_id = sys.argv[1]

thresholds = [1.5,2.,2.5,3.,4.]
for pfam_id in pfam_list:
    try:
        ct = np.loadtxt('../pfam_40_200k/%s_ct.txt'%pfam_id).astype(float)

        for threshold in thresholds:
            ct1 = ct.copy()
            np.fill_diagonal(ct1, 1000)

            # fill the top smallest to be 1, other 0
            top_pos = ct1 <= threshold
            #print(top_pos)
            ct1[top_pos] = 1.
            ct1[~top_pos] = 0.
            #print(ct1) 
            
            xy = np.argwhere(ct1==1)
            #print(xy)
            
            np.savetxt('%s/ct_%1.1f.dat'%(pfam_id,threshold),xy,fmt='% i')

    except:
        pass    
    #=========================================================================================

