import sys
import numpy as np

#pfam_id = 'PF00004'
#pfam_id = sys.argv[1]

s = np.loadtxt('pfam_40_200k.txt',dtype='str')
pfam_list = s[:,0]

#=========================================================================================
def direct_top(d,top):
    # find value of top biggest
    d1 = d.copy()
    np.fill_diagonal(d1, 0)
    #print(d1)
    
    a = d1.reshape((-1,))
    #print(a)    
    a = np.sort(a)[::-1] # descreasing sort
    #print(a)

    top_value = a[top]
    #print(top_value)
       
    # fill the top largest to be 1, other 0
    top_pos = d1 > top_value
    #print(top_pos)
    d1[top_pos] = 1.
    d1[~top_pos] = 0.
    #print(d1) 
    
    xy = np.argwhere(d1==1)   
    return xy

#=========================================================================================
tops = [20,40,60,80,100,120,140]

for pfam_id in pfam_list:
    try:
        di = np.loadtxt('%s/di.dat'%pfam_id)

        for top in tops:
            xy = direct_top(di,top)
            np.savetxt('%s/di_%s.dat'%(pfam_id,top),xy,fmt='%i')

    except:
        pass  
