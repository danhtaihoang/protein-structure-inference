import sys
import numpy as np
import matplotlib
matplotlib.use('TkAgg')
import matplotlib.pyplot as plt

#===================================================================================================
#pfam_id = 'PF00004'
#pfam_id = sys.argv[1]
s = np.loadtxt('pfam_40_200k.txt',dtype='str')
pfam_list = s[:,0]

top = [20,40,60,80,100,120,140]
threshold = [1.5,2.0,2.5,3.0,4.0]

nx = len(top)
ny = len(threshold)

for pfam_id in pfam_list:
    plt.figure(figsize=(18,11))
    for j in range(ny):
        for i in range(nx):
            plt.subplot2grid((5,7),(j,i))
            
            plt.title('ct-thr = %s, di-top = %s' %(threshold[j],top[i]))
            try:
                xy1 = np.loadtxt('%s/ct_%1.1f.dat'%(pfam_id,threshold[j]))    
                xy2 = np.loadtxt('%s/di_%02d.dat'%(pfam_id,top[i]))
            except:
                pass    

            plt.scatter(xy1[:,0],xy1[:,1],marker='o',facecolors='none',edgecolors='c',label='contact',s=13)
            plt.scatter(xy2[:,0],xy2[:,1],marker='o',color='b',label='direct-info',s=3)
            
    plt.tight_layout(h_pad=1, w_pad=1.5)
    plt.savefig('%s/ct_di.pdf'%pfam_id, format='pdf', dpi=50)
    plt.close()    
